﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using Lab.Framework;

namespace $safeprojectname$.Areas.Business.Models
{
    /// <summary>
    /// 请假管理
    /// </summary>
    public partial class Bus_Leave
    {
	
    }
}

