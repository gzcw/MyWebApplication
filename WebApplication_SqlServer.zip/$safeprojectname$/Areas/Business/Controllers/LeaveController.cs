﻿using $safeprojectname$.Areas.Business.Models;
using Lab.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace $safeprojectname$.Areas.Business.Controllers
{
    /// <summary>
    /// 【请假管理】控制器
    /// </summary>
    public partial class LeaveController : StringEntityController<Bus_Leave>
    {
        #region 视图
       
        #endregion
    }
}
