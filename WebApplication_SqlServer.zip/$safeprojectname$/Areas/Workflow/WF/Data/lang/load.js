﻿//定义多语言.
//zh-cn   zh-tw  zh-hk  en-us ja-jp ko-kr
var currentLang = "zh-cn";
//var currentLang = "en-us";
document.write("<script language=javascript src='./Data/lang/js/" + currentLang + ".js'></script>");
document.write("<script language=javascript src='../Data/lang/js/" + currentLang + ".js'></script>");