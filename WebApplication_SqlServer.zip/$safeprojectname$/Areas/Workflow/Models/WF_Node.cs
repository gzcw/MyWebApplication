﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using Lab.Framework;

namespace $safeprojectname$.Areas.Workflow.Models
{
    /// <summary>
    /// 审核组件
    /// </summary>
    public partial class WF_Node
    {
	
    }
}

