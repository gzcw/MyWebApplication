﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;
using Lab.Framework;

namespace $safeprojectname$.Areas.Workflow.Models
{
    /// <summary>
    /// 节点岗位
    /// </summary>
    public partial class WF_NodeStation
    {
	
    }
}

