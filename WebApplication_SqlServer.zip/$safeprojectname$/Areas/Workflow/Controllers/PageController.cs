﻿using $safeprojectname$.Areas.Workflow.Models;
using Lab.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace $safeprojectname$.Areas.Workflow.Controllers
{
    /// <summary>
    /// 【流程页面】控制器
    /// </summary>
    public partial class PageController : StringEntityController<WF_Page>
    {
        #region 视图
       
        #endregion
    }
}
