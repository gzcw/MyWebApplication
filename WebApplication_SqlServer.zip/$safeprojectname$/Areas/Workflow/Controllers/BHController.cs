﻿using $safeprojectname$.Areas.Workflow.Models;
using Lab.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;


namespace $safeprojectname$.Areas.Workflow.Controllers
{
    /// <summary>
    /// 编号控制器
    /// </summary>
    public partial class BHController : StringEntityController<Sys_BH>
    {
        #region 视图
       
        #endregion
    }
}
