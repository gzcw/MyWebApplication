﻿using $safeprojectname$.Areas.Authorize.Models;
using Lab.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace $safeprojectname$.Areas.Authorize.Controllers
{
    /// <summary>
    /// 【岗位】控制器
    /// </summary>
    public partial class StationController : StringEntityController<Auth_Station>
    {
        #region 视图
       
        #endregion
    }
}
