﻿using $safeprojectname$.Areas.Authorize.Models;
using Lab.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace $safeprojectname$.Areas.Authorize.Controllers
{
    /// <summary>
    /// 【角色权限】控制器
    /// </summary>
    public partial class RoleAuthorizationController : StringEntityController<Auth_Rlt_RoleAuthorization>
    {
        #region 视图
       
        #endregion
    }
}
